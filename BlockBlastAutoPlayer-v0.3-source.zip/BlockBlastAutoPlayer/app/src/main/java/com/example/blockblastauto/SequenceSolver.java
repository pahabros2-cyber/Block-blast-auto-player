package com.example.blockblastauto;

import java.util.ArrayList;
import java.util.List;

/**
 * Sequence search for up to three pieces. It explores placements and line clears.
 * It expects a board and piece shapes already recognized by a separate vision layer.
 */
public final class SequenceSolver {
    private SequenceSolver() {}
    public static final class Step {
        public final int pieceIndex, row, col;
        Step(int p,int r,int c){pieceIndex=p;row=r;col=c;}
        @Override public String toString(){return "Фигура "+(pieceIndex+1)+" → ("+(row+1)+","+(col+1)+")";}
    }
    public static final class Plan {
        public final List<Step> steps;
        public final double score;
        Plan(List<Step> s,double v){steps=s;score=v;}
    }
    public static Plan bestPlan(boolean[][] board, PuzzleSolver.Piece[] pieces) {
        Search s = new Search();
        s.dfs(copy(board), pieces, new boolean[pieces.length], new ArrayList<>(), 0, 0);
        return s.best;
    }
    private static final class Search {
        Plan best;
        void dfs(boolean[][] board, PuzzleSolver.Piece[] pieces, boolean[] used,
                 List<Step> path, double score, int depth) {
            if(depth == pieces.length) {
                if(best == null || score > best.score) best = new Plan(new ArrayList<>(path), score);
                return;
            }
            boolean any=false;
            for(int i=0;i<pieces.length;i++) {
                if(used[i]) continue;
                PuzzleSolver.Piece p=pieces[i];
                for(int r=0;r<=10-p.height();r++) for(int c=0;c<=10-p.width();c++) {
                    if(!fits(board,p,r,c)) continue;
                    any=true;
                    boolean[][] next=copy(board);
                    for(int[] cell:p.cells) next[r+cell[0]][c+cell[1]]=true;
                    int cleared=clear(next);
                    double nextScore=score + cleared*100 - roughness(next)*0.5 - holes(next)*2;
                    used[i]=true; path.add(new Step(i,r,c));
                    dfs(next,pieces,used,path,nextScore,depth+1);
                    path.remove(path.size()-1); used[i]=false;
                }
            }
            if(!any && depth>0 && best==null) {
                // no full plan from this branch; caller may later find a viable branch
            }
        }
    }
    private static boolean fits(boolean[][] b,PuzzleSolver.Piece p,int r,int c){
        for(int[] a:p.cells){int y=r+a[0],x=c+a[1];if(y<0||x<0||y>=10||x>=10||b[y][x])return false;}return true;
    }
    private static int clear(boolean[][] b){
        boolean[] rr=new boolean[10],cc=new boolean[10];int n=0;
        for(int r=0;r<10;r++){rr[r]=true;for(int c=0;c<10;c++)rr[r]&=b[r][c];if(rr[r])n++;}
        for(int c=0;c<10;c++){cc[c]=true;for(int r=0;r<10;r++)cc[c]&=b[r][c];if(cc[c])n++;}
        for(int r=0;r<10;r++)for(int c=0;c<10;c++)if(rr[r]||cc[c])b[r][c]=false;
        return n;
    }
    private static double roughness(boolean[][] b){
        int t=0;for(int r=0;r<10;r++)for(int c=0;c<10;c++){
            if(c>0&&b[r][c]!=b[r][c-1])t++;
            if(r>0&&b[r][c]!=b[r-1][c])t++;
        }return t;
    }
    private static int holes(boolean[][] b){
        int n=0;for(int r=1;r<9;r++)for(int c=1;c<9;c++)
            if(!b[r][c]&&b[r-1][c]&&b[r+1][c]&&b[r][c-1]&&b[r][c+1])n++;
        return n;
    }
    private static boolean[][] copy(boolean[][] b){
        boolean[][] n=new boolean[10][10];for(int r=0;r<10;r++)System.arraycopy(b[r],0,n[r],0,10);return n;
    }
}
