package com.example.blockblastauto;

import java.util.ArrayList;
import java.util.List;

/**
 * Basic 10x10 block puzzle search core.
 * Board cells: true means occupied. Piece cells are (row,col) offsets.
 * This is a heuristic scaffold; screen recognition and exact game scoring
 * are intentionally separate modules.
 */
public final class PuzzleSolver {
    public static final int N = 10;
    private PuzzleSolver() {}

    public static final class Piece {
        public final int[][] cells;
        public Piece(int[][] cells) { this.cells = cells; }
        public int height() {
            int m = 0; for (int[] c : cells) m = Math.max(m, c[0]); return m + 1;
        }
        public int width() {
            int m = 0; for (int[] c : cells) m = Math.max(m, c[1]); return m + 1;
        }
    }

    public static final class Move {
        public final int pieceIndex, row, col;
        public final double score;
        Move(int p, int r, int c, double s) { pieceIndex=p; row=r; col=c; score=s; }
        @Override public String toString() {
            return "Фигура " + (pieceIndex + 1) + ": строка " + (row + 1) +
                   ", столбец " + (col + 1) + " (оценка " + String.format("%.1f", score) + ")";
        }
    }

    public static List<Move> findMoves(boolean[][] board, Piece[] pieces) {
        List<Move> result = new ArrayList<>();
        boolean[][] current = copy(board);
        for (int pi = 0; pi < pieces.length; pi++) {
            Piece p = pieces[pi];
            Move best = null;
            for (int r = 0; r <= N - p.height(); r++) {
                for (int c = 0; c <= N - p.width(); c++) {
                    if (!fits(current, p, r, c)) continue;
                    boolean[][] next = copy(current);
                    place(next, p, r, c);
                    int cleared = clearLines(next);
                    double score = cleared * 100.0 - roughness(next) * 0.8 - emptyPockets(next) * 2.0;
                    if (best == null || score > best.score) best = new Move(pi, r, c, score);
                }
            }
            if (best != null) result.add(best);
        }
        result.sort((a,b) -> Double.compare(b.score, a.score));
        return result;
    }

    private static boolean fits(boolean[][] b, Piece p, int r, int c) {
        for (int[] cell : p.cells) {
            int y = r + cell[0], x = c + cell[1];
            if (y < 0 || x < 0 || y >= N || x >= N || b[y][x]) return false;
        }
        return true;
    }
    private static void place(boolean[][] b, Piece p, int r, int c) {
        for (int[] cell : p.cells) b[r+cell[0]][c+cell[1]] = true;
    }
    private static int clearLines(boolean[][] b) {
        boolean[] rows = new boolean[N], cols = new boolean[N];
        int n = 0;
        for (int r=0;r<N;r++) { rows[r]=true; for(int c=0;c<N;c++) rows[r] &= b[r][c]; if(rows[r]) n++; }
        for (int c=0;c<N;c++) { cols[c]=true; for(int r=0;r<N;r++) cols[c] &= b[r][c]; if(cols[c]) n++; }
        for (int r=0;r<N;r++) for(int c=0;c<N;c++) if(rows[r]||cols[c]) b[r][c]=false;
        return n;
    }
    private static double roughness(boolean[][] b) {
        int occupied=0, transitions=0;
        for(int r=0;r<N;r++) for(int c=0;c<N;c++) {
            if(b[r][c]) occupied++;
            if(c>0 && b[r][c]!=b[r][c-1]) transitions++;
            if(r>0 && b[r][c]!=b[r-1][c]) transitions++;
        }
        return transitions + occupied * 0.05;
    }
    private static int emptyPockets(boolean[][] b) {
        int holes=0;
        for(int r=1;r<N-1;r++) for(int c=1;c<N-1;c++)
            if(!b[r][c] && b[r-1][c] && b[r+1][c] && b[r][c-1] && b[r][c+1]) holes++;
        return holes;
    }
    private static boolean[][] copy(boolean[][] src) {
        boolean[][] out = new boolean[N][N];
        for(int r=0;r<N;r++) System.arraycopy(src[r],0,out[r],0,N);
        return out;
    }
}
