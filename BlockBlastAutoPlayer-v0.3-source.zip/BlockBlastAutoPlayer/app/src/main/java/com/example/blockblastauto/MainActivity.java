package com.example.blockblastauto;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 36, 28, 28);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFF101522);

        TextView title = new TextView(this);
        title.setText("Block Blast Auto Player");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView info = new TextView(this);
        info.setText("\nПрототип автоигры. Сначала нужно включить службу специальных возможностей.\n\nВажно: автоматизация пока не распознаёт поле игры и не рассчитывает ходы — это каркас для дальнейшей разработки. Запуск касаний будет добавлен после калибровки поля.");
        info.setTextColor(0xFFE0E5F0);
        info.setTextSize(16);
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));

        Button accessibility = new Button(this);
        accessibility.setText("Открыть настройки специальных возможностей");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility, new LinearLayout.LayoutParams(-1, -2));

        Button overlay = new Button(this);
        overlay.setText("Разрешение на отображение поверх окон");
        overlay.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)));
        root.addView(overlay, new LinearLayout.LayoutParams(-1, -2));

        TextView footer = new TextView(this);
        footer.setText("\nВерсия 0.1 • Android 8+\nНе является готовым читом для игры.");
        footer.setTextColor(0xFF9AA6BD);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }
}
