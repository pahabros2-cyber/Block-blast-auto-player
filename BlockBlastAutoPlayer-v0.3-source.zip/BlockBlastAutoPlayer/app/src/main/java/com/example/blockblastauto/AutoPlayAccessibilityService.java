package com.example.blockblastauto;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/**
 * Safe scaffold only. No automatic taps are issued in this initial build.
 * A real player requires screen-specific vision, coordinate calibration,
 * a solver, and explicit user-controlled start/stop safeguards.
 */
public class AutoPlayAccessibilityService extends AccessibilityService {
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
}
